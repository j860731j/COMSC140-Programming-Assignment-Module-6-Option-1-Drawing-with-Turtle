import turtle

dim = int(input("Enter the dimension: "))
twodim = dim * 2
fivedim = dim * 5
fivehalvesdim = fivedim / 2

turtle.setheading(180)
turtle.forward(fivehalvesdim)

turtle.setheading(270)
turtle.forward(twodim)

turtle.setheading(180)
turtle.forward(dim)

turtle.setheading(90)
turtle.forward(fivedim)

turtle.setheading(0)
turtle.forward(dim)

turtle.setheading(270)
turtle.forward(twodim)

turtle.setheading(0)
turtle.forward(fivedim)

turtle.setheading(90)
turtle.forward(twodim)

turtle.setheading(0)
turtle.forward(dim)

turtle.setheading(270)
turtle.forward(fivedim)

turtle.setheading(180)
turtle.forward(dim)

turtle.setheading(90)
turtle.forward(twodim)

turtle.setheading(180)
turtle.forward(fivehalvesdim)